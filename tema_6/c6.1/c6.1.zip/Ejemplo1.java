/*
 * @author: Christian Millán Soria
 * date: 20/12/2022
 * description: Punto 6.1 - Ejemplo 1
 */

public class Ejemplo1{
  public static void main(String[] args){
    System.out.println("Diez números aleatorios:");

    for(int i=1; i<11; i++){
      System.out.println(Math.random());
    }
  }
}